
from fastapi import FastAPI
from pydantic import BaseModel
app = FastAPI(title='KrishiNexus Orchestrator')

class Query(BaseModel):
    field_id: str
    question: str

@app.post('/plan')
async def plan(query: Query):
    # Placeholder: in production, call RAG retrieval, LLM chain and return plan
    plan = {
        'field_id': query.field_id,
        'actions': [
            {'type':'irrigation', 'when':'2025-08-15T05:00:00', 'amount_liters': 1200},
            {'type':'monitor', 'when':'2025-08-16T06:00:00'}
        ],
        'reason': 'Low soil moisture and upcoming heatwave predicted.'
    }
    return plan

@app.get('/health')
async def health():
    return {'status':'ok'}
