
KrishiNexus Edge Notes
---------------------
This folder holds notes and scripts for edge deployment (Raspberry Pi / Android).
- Use ONNX for model export
- Use ONNX Runtime or tiny inference runtimes for ARM
- Keep models small (distill, quantize)
