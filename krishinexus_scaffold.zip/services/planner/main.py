
from fastapi import FastAPI
app = FastAPI(title='KrishiNexus Planner')

@app.post('/optimize')
async def optimize(payload: dict):
    # Stub: run multi-objective optimization and return schedule
    return {'status':'ok', 'schedule': []}

@app.get('/health')
async def health():
    return {'status':'ok'}
