
# KrishiNexus - Autonomous Multi-Agent Agricultural System (Scaffold)

This repository is a scaffold for the KrishiNexus project — an autonomous multi-agent AI system for Indian agriculture.
It contains starter services, infra, and notes to help you build the full system.

## What's included
- infra/docker-compose.yml (Postgres, Redis, MinIO, Milvus, nginx)
- services/{oracle,orchestrator,planner,execution} - FastAPI stubs
- web/farmer-pwa - placeholder frontend
- models, tooling/scripts - model & edge notes
- KrishiNexus.pdf (project synopsis) should be attached separately

## Quickstart (local)
1. Start core infra:
   ```bash
   cd infra
   docker-compose up -d
   ```
2. Start a service (example):
   ```bash
   cd services/oracle
   pip install fastapi uvicorn
   uvicorn main:app --reload --port 8010
   ```

## Next steps
- Implement RAG pipeline using sentence-transformers + Milvus
- Add agent orchestration using LangChain-style flows
- Build Farmer PWA with voice capture and offline sync
- Implement edge packaging (ONNX) for on-device inference
